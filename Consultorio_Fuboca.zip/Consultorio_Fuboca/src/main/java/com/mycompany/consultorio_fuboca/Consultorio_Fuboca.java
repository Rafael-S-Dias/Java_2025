/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consultorio_fuboca;

/**
 *
 * @author aluno.den
 */
import com.mycompany.consultorio_fuboca.view.Tela;

public class Consultorio_Fuboca {

    public static void main(String[] args) {
        Tela t = new Tela();
        t.setVisible(true);
    }
}
